import Clutter from 'gi://Clutter';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {
    COLUMNS_COUNT,
    ROWS_COUNT,
    GRID_MARGIN_PX,
    GRID_GAP_PX,
    checkOverlap,
    calculateResizedDimensions,
    calculateGridDimensions,
    getWidgets,
    saveWidgets,
    deleteCacheFile,
    readGlobalSettings
} from '../utils/widgetUtils.js';
import { getWidgetsForMonitor, getPanelHeight, getEffectiveMonitorIndex } from './helpers.js';
import { registerWidgetCleanup } from '../shell/widgetUIUtils.js';
import { openWidgetContextMenu } from './contextMenu.js';
import {
    BUTTON_PRIMARY,
    BUTTON_SECONDARY,
    DRAG_MOTION_THRESHOLD_PX,
} from './constants.js';

/** Segédfüggvény a célterület előnézeti keretének (Drop Placeholder) kezelésére */
function updateDropPlaceholder(grid, targetCol, targetRow, colSpan, rowSpan, isValid) {
    if (!grid._dropPlaceholder) {
        grid._dropPlaceholder = new St.Widget({
            name: 'dropPlaceholder',
            reactive: false
        });
        // A rácsvonalak fölé, de a widgetek alá/mögé tesszük
        grid.insert_child_at_index(grid._dropPlaceholder, 1);
    }

    const cellSize = grid.cellSize || (grid.cellTotalWidth - (GRID_GAP_PX || 8));
    const gap = (typeof GRID_GAP_PX !== 'undefined') ? GRID_GAP_PX : 8;
    const margin = (typeof GRID_MARGIN_PX !== 'undefined') ? GRID_MARGIN_PX : 8;

    const width = Math.max(1, Math.round((colSpan * cellSize) + ((colSpan - 1) * gap)));
    const height = Math.max(1, Math.round((rowSpan * cellSize) + ((rowSpan - 1) * gap)));
    const x = Math.max(0, Math.round(margin + (targetCol * grid.cellTotalWidth)));
    const y = Math.max(0, Math.round(margin + (targetRow * grid.cellTotalHeight)));

    grid._dropPlaceholder.set_size(width, height);
    grid._dropPlaceholder.set_position(x, y);

    const accentColor = readGlobalSettings(grid.settings, grid.interfaceSettings).globalAccentColor || '#3584e4';
    
    // Zöld/Kék ha szabad, Piros ha ütközik
    if (isValid) {
        grid._dropPlaceholder.set_style(`
            background-color: rgba(53, 132, 228, 0.25);
            border: 2px dashed ${accentColor};
            border-radius: 12px;
        `);
    } else {
        grid._dropPlaceholder.set_style(`
            background-color: rgba(224, 27, 36, 0.25);
            border: 2px dashed #e01b24;
            border-radius: 12px;
        `);
    }
    grid._dropPlaceholder.show();
}

function removeDropPlaceholder(grid) {
    if (grid._dropPlaceholder) {
        grid._dropPlaceholder.destroy();
        grid._dropPlaceholder = null;
    }
}

function resolveWidgetMonitor(grid, currentMonitor) {
    if (currentMonitor) return currentMonitor;

    const globalMonitor = grid.settings.get_string('global-monitor') || 'primary';
    
    // Ha a beállításokban egy konkrét monitor van kiválasztva ('primary' vagy szám)
    if (globalMonitor !== 'each' && globalMonitor !== 'all') {
        return globalMonitor;
    }

    // Ha 'each' módban vagyunk, a grid aktuális monitor indexét rendeljük hozzá:
    const primaryIdx = global.display ? global.display.get_primary_monitor() : 0;
    if (grid.targetMonitorIndex === null || grid.targetMonitorIndex === primaryIdx) {
        return 'primary';
    }

    return String(grid.targetMonitorIndex);
}

function endDrag(state, grid, node, widgetData) {
    if (state.dragMotionId) { global.stage.disconnect(state.dragMotionId); state.dragMotionId = 0; }
    if (state.dragReleaseId) { global.stage.disconnect(state.dragReleaseId); state.dragReleaseId = 0; }
    
    // Eltávolítjuk a célzóna előnézetét
    removeDropPlaceholder(grid);

    if (state.isDragging) {
        state.isDragging = false;

        const widgets = getWidgets(grid.settings).map(w => {
            if (!w.monitor) {
                w.monitor = resolveWidgetMonitor(grid, w.monitor);
            }
            return w;
        });
        
        const targetWidget = widgets.find(w => w.id === widgetData.id);

        if (targetWidget) {
            const monitorSetting = grid.settings.get_string('global-monitor') || 'primary';
            const monitors = Main.layoutManager.monitors || [];

            const widgetStageX = grid.x + node.x;
            const widgetStageY = grid.y + node.y;
            const widgetCenterX = widgetStageX + (node.width / 2);
            const widgetCenterY = widgetStageY + (node.height / 2);

            let targetMonitorIndex = null;
            let targetMonitor = null;

            if (monitorSetting === 'each' && monitors.length > 1) {
                for (let i = 0; i < monitors.length; i++) {
                    const mon = monitors[i];
                    if (widgetCenterX >= mon.x && widgetCenterX < mon.x + mon.width &&
                        widgetCenterY >= mon.y && widgetCenterY < mon.y + mon.height) {
                        targetMonitorIndex = i;
                        targetMonitor = mon;
                        break;
                    }
                }
            }

            if (targetMonitorIndex !== null && targetMonitor) {
                const primaryMon = Main.layoutManager.primaryMonitor;
                const isPrimary = primaryMon ? (targetMonitor === primaryMon) : (targetMonitorIndex === 0);
                const topOffset = isPrimary ? getPanelHeight() : 0;

                const localX = widgetStageX - targetMonitor.x;
                const localY = widgetStageY - (targetMonitor.y + topOffset);

                const targetMonWidgets = getWidgetsForMonitor(widgets, targetMonitorIndex, true);
                const otherWidgetsOnTargetMon = targetMonWidgets.filter(widget => widget.id !== widgetData.id);

                const gridCols = grid.gridCols || COLUMNS_COUNT;
                const { cellTotalWidth, cellTotalHeight, gridRows } = calculateGridDimensions(targetMonitor.width, targetMonitor.height - topOffset, gridCols);

                const targetCol = Math.max(0, Math.min(gridCols - targetWidget.width, Math.round((localX - GRID_MARGIN_PX) / cellTotalWidth)));
                const targetRow = Math.max(0, Math.min(gridRows - targetWidget.height, Math.round((localY - GRID_MARGIN_PX) / cellTotalHeight)));

                if (!checkOverlap(targetCol, targetRow, targetWidget.width, targetWidget.height, otherWidgetsOnTargetMon)) {
                    targetWidget.x = targetCol;
                    targetWidget.y = targetRow;
                    targetWidget.monitor = isPrimary ? 'primary' : String(targetMonitorIndex);

                    const movedNode = grid.widgetNodes.get(targetWidget.id);
                    if (movedNode) {
                        movedNode.destroy();
                        grid.widgetNodes.delete(targetWidget.id);
                        grid._nodeConfigs.delete(targetWidget.id);
                    }
                    grid.applyLocalWidgetLayout(widgets);
                } else {
                    grid._repositionNode(targetWidget.id, targetWidget.width, targetWidget.height, state.origGridX, state.origGridY);
                }
            } else {
                const activeWidgets = getWidgetsForMonitor(widgets, grid.targetMonitorIndex, true);
                const gridCols = grid.gridCols || COLUMNS_COUNT;
                const gridRows = grid.gridRows || ROWS_COUNT;
                
                // Ha az asztali ikonok külön listában (is) élnek a grid-en, azokat is vonjuk be az otherWidgets-be:
                let allOccupiedWidgets = [...activeWidgets];
                if (grid._desktopIconWidgets && Array.isArray(grid._desktopIconWidgets)) {
                    // Hozzáfűzzük az asztali ikonok adatait is, ha nem a most mozgatott elemről van szó
                    for (const dIcon of grid._desktopIconWidgets) {
                        if (!allOccupiedWidgets.some(w => w.id === dIcon.id)) {
                            allOccupiedWidgets.push(dIcon);
                        }
                    }
                }

                const otherWidgets = allOccupiedWidgets.filter(widget => widget.id !== widgetData.id);

                const targetCol = Math.max(0, Math.min(gridCols - targetWidget.width, Math.round((node.x - GRID_MARGIN_PX) / grid.cellTotalWidth)));
                const targetRow = Math.max(0, Math.min(gridRows - targetWidget.height, Math.round((node.y - GRID_MARGIN_PX) / grid.cellTotalHeight)));

                if (!checkOverlap(targetCol, targetRow, targetWidget.width, targetWidget.height, otherWidgets)) {
                    targetWidget.x = targetCol;
                    targetWidget.y = targetRow;

                    // Mentsük el a beállításokat, hogy perzisztens maradjon:
                    grid.applyLocalWidgetLayout(widgets);

                    // FONTOS: Vagy töröljük a node-ot az újraépítés előtt, VAGY csak mozgatjuk!
                    // A legegyszerűbb és leggyorsabb: csak átpozicionáljuk a meglévő actort,
                    // és NEM hívunk applyLocalWidgetLayout-ot, ami duplikálná:
                    grid._repositionNode(targetWidget.id, targetWidget.width, targetWidget.height, targetCol, targetRow);
                } else {
                    // Ha ütközik: visszaugrik az eredeti cellájára
                    grid._repositionNode(targetWidget.id, targetWidget.width, targetWidget.height, state.origGridX, state.origGridY);
                }
            }
        }
        grid.constructor.toggleAllGridOverlays(false);
    }
}

function getActiveDrag(grid) {
    if (!grid._activeDrag) grid._activeDrag = null;
    return grid._activeDrag;
}

function setActiveDrag(grid, value) {
    grid._activeDrag = value;
}

function cancelInterruptedDrag(grid) {
    const activeDrag = getActiveDrag(grid);
    if (!activeDrag) return;
    const { state, node, widgetData } = activeDrag;
    setActiveDrag(grid, null);
    endDrag(state, grid, node, widgetData);
}

export function attachDragHandlers(grid, node, widgetData) {
    let pressX = 0;
    let pressY = 0;
    const state = { isDragging: false, dragMotionId: 0, dragReleaseId: 0, startX: 0, startY: 0, origGridX: 0, origGridY: 0 };

    const finishDrag = () => {
        const currentDrag = getActiveDrag(grid);
        if (currentDrag && currentDrag.state === state) setActiveDrag(grid, null);
        endDrag(state, grid, node, widgetData);
    };

    node.connect('button-press-event', (_actor, event) => {
        if (event.get_button() === BUTTON_SECONDARY) {
            openWidgetContextMenu(grid, event, node, widgetData);
            return Clutter.EVENT_STOP;
        }

        if (event.get_button() === BUTTON_PRIMARY) {
            cancelInterruptedDrag(grid);

            [pressX, pressY] = event.get_coords();
            state.startX = node.x;
            state.startY = node.y;
            state.origGridX = widgetData.x;
            state.origGridY = widgetData.y;

            if (state.dragMotionId) { global.stage.disconnect(state.dragMotionId); state.dragMotionId = 0; }
            if (state.dragReleaseId) { global.stage.disconnect(state.dragReleaseId); state.dragReleaseId = 0; }

            state.dragMotionId = global.stage.connect('motion-event', (_stage, ev) => {
                const evState = ev.get_state();
                if (!(evState & Clutter.ModifierType.BUTTON1_MASK)) {
                    finishDrag();
                    return Clutter.EVENT_PROPAGATE;
                }

                const [curX, curY] = ev.get_coords();
                const dx = curX - pressX;
                const dy = curY - pressY;

                if (!state.isDragging && (Math.abs(dx) > DRAG_MOTION_THRESHOLD_PX || Math.abs(dy) > DRAG_MOTION_THRESHOLD_PX)) {
                    state.isDragging = true;
                    grid.constructor.toggleAllGridOverlays(true);
                }

                if (state.isDragging) {
                    const newPosX = state.startX + dx;
                    const newPosY = state.startY + dy;
                    node.set_position(newPosX, newPosY);

                    // Drop Target Placeholder frissítése a rácson
                    const gridCols = grid.gridCols || COLUMNS_COUNT;
                    const gridRows = grid.gridRows || ROWS_COUNT;
                    const targetCol = Math.max(0, Math.min(gridCols - widgetData.width, Math.round((newPosX - GRID_MARGIN_PX) / grid.cellTotalWidth)));
                    const targetRow = Math.max(0, Math.min(gridRows - widgetData.height, Math.round((newPosY - GRID_MARGIN_PX) / grid.cellTotalHeight)));

                    const widgets = getWidgets(grid.settings).map(w => {
                        if (!w.monitor) {
                            w.monitor = resolveWidgetMonitor(grid, w.monitor);
                        }
                        return w;
                    });

                    const activeWidgets = getWidgetsForMonitor(widgets, grid.targetMonitorIndex, true);
                    const otherWidgets = activeWidgets.filter(w => w.id !== widgetData.id);
                    const isValid = !checkOverlap(targetCol, targetRow, widgetData.width, widgetData.height, otherWidgets);

                    updateDropPlaceholder(grid, targetCol, targetRow, widgetData.width, widgetData.height, isValid);

                    return Clutter.EVENT_STOP;
                }
                return Clutter.EVENT_PROPAGATE;
            });

            state.dragReleaseId = global.stage.connect('button-release-event', (_stage, ev) => {
                if (ev.get_button() === BUTTON_PRIMARY) {
                    finishDrag();
                }
                return Clutter.EVENT_PROPAGATE;
            });

            setActiveDrag(grid, { state, grid, node, widgetData });
        }
        return Clutter.EVENT_PROPAGATE;
    });

    registerWidgetCleanup(node, () => {
        const currentDrag = getActiveDrag(grid);
        if (currentDrag && currentDrag.state === state) setActiveDrag(grid, null);
        cancelInterruptedDragForState(state);
        removeDropPlaceholder(grid);
    });
}

function cancelInterruptedDragForState(state) {
    if (state.dragMotionId) { global.stage.disconnect(state.dragMotionId); state.dragMotionId = 0; }
    if (state.dragReleaseId) { global.stage.disconnect(state.dragReleaseId); state.dragReleaseId = 0; }
}

export function onWidgetResized(grid, widgetId, newCols, newRows, newX) {
    const allWidgets = getWidgets(grid.settings);
    const monitorMode = grid.settings.get_string('global-monitor') || 'primary';
    const isEachMode = (monitorMode === 'each');
    const activeWidgets = getWidgetsForMonitor(allWidgets, getEffectiveMonitorIndex(grid.targetMonitorIndex, grid.settings), isEachMode);
    const widget = activeWidgets.find(activeWidget => activeWidget.id === widgetId);
    if (!widget) return;

    const otherWidgets = activeWidgets.filter(activeWidget => activeWidget.id !== widgetId);
    const gridCols = grid.gridCols || COLUMNS_COUNT;
    const gridRows = grid.gridRows || ROWS_COUNT;
    const { validCols, validRows, validX } = calculateResizedDimensions(widget, newCols, newRows, newX, otherWidgets, gridCols, gridRows);

    if (!checkOverlap(validX, widget.y, validCols, validRows, otherWidgets)) {
        const targetWidget = allWidgets.find(existingWidget => existingWidget.id === widgetId);
        if (targetWidget) {
            targetWidget.width = validCols;
            targetWidget.height = validRows;
            targetWidget.x = validX;
            grid.applyLocalWidgetLayout(allWidgets);
            grid._repositionNode(widgetId, validCols, validRows, validX, widget.y);
        }
    }
}

export function onWidgetDeleted(grid, widgetId) {
    const widgets = getWidgets(grid.settings);
    const targetWidget = widgets.find(widget => widget.id === widgetId);
    if (targetWidget) {
        if (targetWidget.type === 'notes') {
            deleteCacheFile('notes', widgetId);
        } else if (targetWidget.type === 'clipboard') {
            deleteCacheFile('clipboard', widgetId);
        } else if (targetWidget.type === 'todo') {
            deleteCacheFile('todos', widgetId);
        } else if (targetWidget.type === 'github') {
            deleteCacheFile('github', widgetId);
        }
    }
    const remainingWidgets = widgets.filter(widget => widget.id !== widgetId);
    saveWidgets(grid.settings, remainingWidgets);
}